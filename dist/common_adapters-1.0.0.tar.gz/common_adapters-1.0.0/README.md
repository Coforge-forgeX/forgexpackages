# common-adapters
Reusable adapters.